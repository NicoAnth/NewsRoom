# Rapport Semaine 4

## Rôles

### Responsable Thomas Ramaromananatoandro

* Déploiement du projet sur glitch.
* Utilisation d'un élément appelé partial pour le header des pages articles.
* Séparation du code js logique et du code js d'affichage. 
* Test d'un filtre afin de garantir la qualité des nouvelles au niveau des sources.
* Listing de différentes sources /liens et les balises correspondant à l'article de newsapi effectué dans le but de pouvoir extraire directement le contenu textuel de la source d'article (scrapping) à l'aide de jsdom par exemple.


### Chercheur Nicolas Anthene

* Suivi régulier des équipes.
* Recherches sur des moyens de déployer le projet glitch sur github
* Recherches sur des fonctionnalités avancées en github (push un commit antérieur sur glitch...).
* Synchronisation des différentes versions du projet github au projet glitch.
* Identification et résolution d'un problème concernant le fonctionnement de l'API Newsapi sur Glitch.

### Codeur Yacine Yousfi

* Implémentation des fonctionnalités login et logout avec des sessions.


### Rapporteur Junyi WU

* Suivi régulier des équipes.
* Recherche sur des différentes solutions à envoyer des mails avec nodejs.
* Creation et configuration du mail officiel du site.
* Création de la page mailsletter.
* Configuration et implémentation de la fonctionnalité mailsletter du projet.
* Réalisation des tests de fonctionnement afin de garantir la bon déroulement de la mailsletter.


### Groupe

--les tâches prévues réalisées
* Revoir les fonctionnalités et réajuster les objectifs pour celles-ci 
* Déployer notre projet sur glitch
* Ajout front pour newsletter
* Implémentation newsletter

--les tâches hebdomadaires
* Résolution de plusieurs bugs important concernant le deploiement du projet.
* Mise en commun des informations.
* Présentation des tâches effectuées par l'équipe.

## Organisation

Nous avons effectué une réunion afin de résoudre certains bugs important et revoir le déroulement de chaque partie de projet.
Dû à l'indisponibilité de Yacine nous avons décidé de tout de même faire la réunion à 3 et de lui résumer son contenu et nos remarques par écrit.


## Problèmes rencontrés :

Notre codeur n'a pas assez avancé sur ce qui été prévu.
Les tâches suivantes n'ont pas été réalisées :
* Implémentation des interactions Base de donnée/Site (login/logout/mesfavoris)
* Ajout d'un bouton pour ajouter un article aux favoris
* Ajout front pour compte utilisateur, mesfavoris
* Implémentation de la fonctionnalité mesfavoris 

## Liens

[Librairie client Node non-officielle newsapi](https://github.com/jsdom/jsdom)

[Mieux comprendre EJS](https://www.youtube.com/watch?v=FhZj6aysmII)

[Familiarisation aux partials avec EJS](https://raddy.co.uk/blog/nodejs-express-layouts-and-partials/)

[Use EJS as Template Engine in Node.js](https://medium.com/@osiolabs/read-write-json-files-with-node-js-92d03cc82824)

[jsdom](https://github.com/jsdom/jsdom)

[Node.js](https://nodejs.org/en/docs/)

[Express.js](https://expressjs.com/fr/api.html#express)

[Express.js: middleware, body-parser](http://expressjs.com/en/resources/middleware/body-parser.html)

[Glitch et Node.js](https://blog.bitsrc.io/introduction-to-glitch-for-node-js-apps-in-the-cloud-cd263de5683f)

[Listing de différentes sources /liens et les balises correspondant pour le texte d'article](https://docs.google.com/spreadsheets/d/1gg2Qljpdrv8dMgqrO6NgONOFLBO8nGHgIli9kXz48ws/edit#gid=0)

[NODEMAILER](https://nodemailer.com/about/)
